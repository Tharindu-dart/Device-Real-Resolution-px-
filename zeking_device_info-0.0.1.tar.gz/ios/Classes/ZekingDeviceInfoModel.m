//
//  ZekingDeviceInfoModel.m
//  MJExtension
//
//  Created by 李樟清 on 2020/4/24.
//

#import "ZekingDeviceInfoModel.h"

@implementation ZekingDeviceInfoModel

@end

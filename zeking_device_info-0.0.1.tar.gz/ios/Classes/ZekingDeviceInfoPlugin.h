#import <Flutter/Flutter.h>

@interface ZekingDeviceInfoPlugin : NSObject<FlutterPlugin>
@end
